import Image from "next/image";
import style from './pagestyle.module.css'
export default function Home() {
  return (
    // <div className={style.heading}>
    //   E-Commerce
    // </div>
    <></>
  );
}
